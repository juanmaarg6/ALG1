function[q]=cociente(a,b)
% cociente de la división con resto en Z
	q= floor (a/b);

