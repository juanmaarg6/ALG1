function[r]=resto(a,b)
% resto de la división con resto en Z
r= a - b* cociente(a,b);
