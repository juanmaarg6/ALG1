function[r]=resto(a,b)
% resto extiende la division con resto a Z[i]
r= a - b* cociente(a,b);
