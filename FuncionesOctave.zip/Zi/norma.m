function[n]=norma(a)
n=real(a)^2 +imag(a)^2;